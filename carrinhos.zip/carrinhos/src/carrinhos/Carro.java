package carrinhos;

public class Carro {
	
	String marca;
	String modelo;
	String cor;
	int km;
	int capTanque;
	int kmPorLitro;
	double preco;
	
		
	int calcularKm() {
		return capTanque * kmPorLitro;
	}
	
	double calcularDesconto(double percentualDescontoVendedor) {
		if (percentualDescontoVendedor>=0 && percentualDescontoVendedor<=4) {
			return preco * (percentualDescontoVendedor / 100);
		}else if(percentualDescontoVendedor < 0) {
			return 0;
		}else {
			return preco = 0.04;
		}
	
}
