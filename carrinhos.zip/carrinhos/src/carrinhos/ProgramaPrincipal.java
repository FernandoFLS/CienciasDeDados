package carrinhos;

public class ProgramaPrincipal {

	public static void main(String[] args) {
	
		Carro novoCarro = new Carro();
		novoCarro.setMarca = ("VW");
		novoCarro.setModelo = ("Fox");
		novoCarro.setCor = ("Azul");
		novoCarro.setKm = ("15560");
		novoCarro.setCapTanque = (40);
		novoCarro.setKmPorLitro = (11);
		novoCarro.setPreco = (50000);
		
		System.out.println("Marca: " + novoCarro.getMarca());
		System.out.println("Modelo: " + novoCarro.getModelo());
		System.out.println("Cor: " + novoCarro.getCor());
		System.out.println("KM: " + novoCarro.getKm());
		System.out.println("KM por Litro: " + novoCarro.getKmPorLitro());
		System.out.println("Preço: " + novoCarro.getPreco());
		System.out.println("Desconto: " + novoCarro.calcularDesconto(1,2));
		

		
		//carro2
		
		Carro novoCarro2 = new Carro();
		novoCarro2.setMarca = ("Honda");
		novoCarro2.setModelo = ("Civic");
		novoCarro2.setCor = ("Preto");
		novoCarro2.setKm = ("18000");
		novoCarro2.setCapTanque = (45);
		novoCarro2.setKmPorLitro = (10);
		novoCarro2.setPreco = (65000);
		
		System.out.println("Marca: " + novoCarro2.getMarca());
		System.out.println("Modelo: " + novoCarro2.getModelo());
		System.out.println("Cor: " + novoCarro2.getCor());
		System.out.println("KM: " + novoCarro2.getKm());
		System.out.println("KM por Litro: " + novoCarro2.getKmPorLitro());
		System.out.println("Preço: " + novoCarro2.getPreco());
		System.out.println("Desconto: " + novoCarro2.calcularDesconto(1,2));

		
}
}
\